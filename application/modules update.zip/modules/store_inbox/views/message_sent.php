
<?php
$back = base_url().'store_inbox';
?>
<div class="tab-pane fade in active">

	<div class="row">
		<div class="col-md-6">
	    	<h2><?= $headline ?></h2>
	    </div>

	    <div class="col-md-6">
	        <a href="<?= $back ?>" class="button btn-small yellow pull-right">BACK</a>
	    </div>
	</div>  

	<div>
		<p>Your message has been successfully sent. Thanks !</p>
	</div>

</div>
