<article class="box">
                                <figure class="col-sm-4">
                                    <a title="" href="http://localhost:85/hmvc/product/billboard/Jl-Ahmad-Yani-Depan-Suzuya-Plaza-View-Dari-Pusat-Kota-Rantau-Parapat-Sisi-B-1717060001" class=""><img width="270" height="160" alt="" src="http://placehold.it/270x160"></a>
                                    <div class="rel-category">
                                        <span class="label label-warning">Billboard</span>
                                    </div>
                                </figure>
                                
                                <div class="details col-sm-8">
                                    <div class="clearfix">
                                    	<div class="col-xs-7 alamat-lokasi">
                                    		
                                				<h5 class="box-title pull-left" style="line-height: 18px"><i class="soap-icon-departure yellow-color"></i> <a href="http://localhost:85/hmvc/product/billboard/Jl-Ahmad-Yani-Depan-Suzuya-Plaza-View-Dari-Pusat-Kota-Rantau-Parapat-Sisi-B-1717060001">Jl. Ahmad Yani ( Depan Suzuya Plaza, View Dari Pusat Kota Rantau Parapat, Sisi B ) </a></h5>
                                			
                                        	<div>
                                        		<span class="skin-color"><strong>#1717060001</strong></span>
                                        	</div>

										</div>
										<div class="col-xs-5">
                                        	<span class="price pull-right">Rp. 300.000.000</span>
                                        </div>
                                    </div>
                                    <div class="character clearfix">
                                        <div class="col-xs-3 date">
                                            <div class="col-xs-8">
	                                            <i class="soap-icon-clock yellow-color"></i>
	                                            <div>
	                                                <span class="skin-color">Durasi</span><br>4 bulan
	                                            </div>
                                            </div>
                                            <div class="col-xs-3">
                                            	<a href="javascript:void(0);" data-id="1" data-title="Jl. Ahmad Yani ( Depan Suzuya Plaza, View Dari Pusat Kota Rantau Parapat, Sisi B )" class="openPopup" title="edit">
                                            		<div class="icon-box style8">
                                            			<i class="fa fa-pencil-square-o" style="font-size: 18px; float: left; line-height: 28px"></i>
                                            		</div>
                                            	</a>

                                            </div>
                                        </div>
                                        <div class="col-xs-3 date">
                                            <i class="soap-icon-calendar yellow-color"></i>
                                            <div>
                                                <span class="skin-color">Jadwal Tayang</span>
                                                <br>
                                                <table class="jadwal">
                                                	<tbody>
                                                		<tr class="start">
                                                			<td>Awal :</td>
                                                			<td width="10%"> </td>
                                                			<td> 
                                                				13/06/2018                                                			</td>
                                                		</tr>
                                                		<tr class="end">
                                                			<td>Akhir :</td>
                                                			<td width="10%"> </td>
                                                			<td>
                                                				11/07/2018                                                			</td>
                                                		</tr>
                                                	</tbody>
                                                </table>
                                               
                                            </div>
                                        </div>
                                        <div class="col-xs-3 departure">
                                            <div>
                                             
                                                <table class="">
                                                	<tbody>
                                                		<tr class="">
                                                			<td class="skin-color">Ukuran :</td>
                                                			<td width="10%"> </td>
                                                			<td> 6x12 m</td>
                                                		</tr>
                                                		<tr class="">
                                                			<td class="skin-color">Display :</td>
                                                			<td width="10%"> </td>
                                                			<td> Vertikal</td>
                                                		</tr>
                                                		<tr class="">
                                                			<td class="skin-color">Lampu :</td>
                                                			<td width="10%"> </td>
                                                			<td> Back Light</td>
                                                		</tr>
                                                	</tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="col-xs-3 departure">
                                        	<div>
	                                            <table class="">
                                                	<tbody>
                                                		<tr class="">
                                                			<td class="skin-color">Sisi :</td>
                                                			<td width="10%"> </td>
                                                			<td> satu sisi</td>
                                                		</tr>
                                                		<tr class="">
                                                			<td class="skin-color">Jalan :</td>
                                                			<td width="10%"> </td>
                                                			<td> Kelas II</td>
                                                		</tr>
                                                		
                                                	</tbody>
                                                </table>
	                                        </div>
                                        </div>
                                    </div>
                                    <div class="clearfix">
                                        <div class="review pull-left">
                                            <div class="five-stars-container">
                                                <span class="five-stars" style="width: 0%;"></span>
                                            </div>
                                            <span>0 reviews</span>
                                        </div>
                                        <a href="#" class="button btn-small red pull-right"><i class="fa fa-trash"></i> Hapus</a>
                                    </div>
                                </div>
                            </article>