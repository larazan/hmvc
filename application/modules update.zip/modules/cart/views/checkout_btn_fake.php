<!-- <div class="col-md-10 col-md-offset-1" style="text-align: center;">
	<a href="<?php echo base_url().'cart/go_to_checkout/'.$checkout_token; ?>">
		<button type="button" class="brn btn-danger" name="submit" value="Submit">
			Checkout
		</button>
	</a>
</div> -->

<a href="<?php echo base_url().'cart/go_to_checkout/'.$checkout_token; ?>">
	<button class="button btn-large orange full-width">Checkout</button>
</a>